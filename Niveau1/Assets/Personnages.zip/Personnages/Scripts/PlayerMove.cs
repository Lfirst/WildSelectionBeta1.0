﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMove : MonoBehaviour {
    public CharacterController CharControl;
    public Animator anim;
    public float WalkSpeed ;
    public float RunSpeed;
    public float jumpforce = 10f;
    private float jumpVelocity;
    public float gravity = 14f;
    bool jump = false;
    bool jumping = false;
    // Use this for initialization
    void Awake()
    {
        CharControl = GetComponent<CharacterController>();
    }
	
	// Update is called once per frame
	void Update ()
    {
        MovePlayer();
        Jump();
	}
    void MovePlayer()
    {
        float horiz = Input.GetAxis("Horizontal");
        float run = Input.GetAxis("Run");
        float vert = Input.GetAxis("Vertical");

        Vector3 moveDirSide = transform.right * horiz * (WalkSpeed + run * RunSpeed);
        Vector3 moveDireForward = transform.forward * vert * (WalkSpeed + run * RunSpeed);

        
        if (CharControl.isGrounded)
        {
            jumpVelocity = -gravity * Time.deltaTime;
            if (Input.GetKeyDown(KeyCode.Space))
            {
                jumpVelocity = jumpforce;
            }
        }
        else
        {
            jumpVelocity -= gravity * Time.deltaTime;
        }
        Vector3 moveDirUp = Vector3.zero ;

        moveDirUp.x = moveDirSide.x + moveDireForward.x;
        moveDirUp.y = jumpVelocity + moveDirSide.y + moveDireForward.y;
        moveDirUp.z = moveDireForward.z + moveDirSide.z;
        CharControl.Move(moveDirUp *Time.deltaTime);

    }
    //Animation Jump
    void Jump()
    {
        anim.SetBool("Grounded", CharControl.isGrounded);
        anim.SetFloat("AirVelocity", jumpVelocity);
    }
   
}
