﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerAnimations : MonoBehaviour {

    private Animator anim;
    private float horiz;
    private float vert;
    private float run;

    void Start()
    {
        anim = GetComponent<Animator>();
    }

    void Update()
    {
        //Horizontal direction :
        horiz = Input.GetAxis("Horizontal");
        anim.SetFloat("Horizontal", horiz);

        //Run/Walk
        run = Input.GetAxis("Run");
        anim.SetFloat("Run", run);

        //Vertical direction :
        vert = Input.GetAxis("Vertical");
        anim.SetFloat("Vertical", vert);



        
    }
}
